package myPackage;

import java.util.HashMap;
import java.util.Map;

public class stateLookup {
	private Map <String, StatePair>states;
	public stateLookup() {
		states = new HashMap<String, StatePair>();
		addState(new StatePair("California","CA"));
				
	}
	public StatePair findState(String name) {
		if(name!=null)
			return (states.get(name));
		return null;
	}
	private void addState(StatePair statePair) {
		states.put(statePair.getStateName(), statePair);
	}
}
