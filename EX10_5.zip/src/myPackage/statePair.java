package myPackage;

public class statePair {
	private final String stateName, stateAbbreviation;
	public statePair(String stateName,String stateAbbreviation) {
		this.stateName=stateName;
		this.stateAbbreviation=stateAbbreviation;
	}
	public String getStateName() {
		return stateName;
	}
	public String getStateAbbreviation() {
		return stateAbbreviation;
	}
}
