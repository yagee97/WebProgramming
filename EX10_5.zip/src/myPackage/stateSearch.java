package myPackage;

import java.util.HashMap;
import java.util.Map;

public class stateSearch {
	private Map <String, statePair>states;
	public stateSearch() {
		states = new HashMap<String, statePair>();
		addState(new statePair("California","CA"));
				
	}
	public statePair findState(String name) {
		if(name!=null)
			return (states.get(name));
		return null;
	}
	private void addState(statePair statePair) {
		states.put(statePair.getStateName(), statePair);
	}
}
