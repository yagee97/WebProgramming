package myPackage;

public class Car {
    private String name;
	private String maker;
    private int year;
    public Car(){}
    public Car(String name,int year,String maker)
    {
    	setMaker(maker);
    	setName(name);
    	setYear(year);
    }
    public void setMaker(String maker)
    {
    	this.maker=maker;
    }
    public void setName(String name)
    {
    	this.name=name;
    }
    public void setYear(int year)
    {
    	this.year=year;
    }
    public String getName()
    {
    	return name;
    }
    public String getMaker()
    {
    	return maker;
    }
    public int getYear()
    {
    	return year;
    }
	public void printInfo()
	{
		System.out.printf("\n%s %d %s",getName(),getYear(),getMaker());
	}
}