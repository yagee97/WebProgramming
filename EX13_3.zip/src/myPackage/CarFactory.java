package myPackage;

public class CarFactory{
	public static Car makeCar(String name,int year)
	{
		if(name.equalsIgnoreCase("Sonata") && year==2010)
			return new Car(name,year,"Hyundai");
		else if(name.equalsIgnoreCase("Avante") && year==2013)
			return new Car(name,year,"Hyundai");
		else if(name.equalsIgnoreCase("A6") && year==2015)
			return new Car(name,year,"Audi");
		else if(name.equalsIgnoreCase("R8") && year==2017)
			return new Car(name,year,"Audi");

		return new Car(name,year,"");
	}
	public static Car makeCar(String name,int year,String maker)
	{
		return new Car(name,year,maker);
	}
}