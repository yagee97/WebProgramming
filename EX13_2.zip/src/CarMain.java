
import org.springframework.context.*;
import org.springframework.context.support.*;

public class CarMain {
	public static void main(String[] args) {
		
		Car.setCar();
		
		ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");
		
		Car c1 = (Car) context.getBean("car1");
		c1.printInfo();
		System.out.println("\n-----------------");
		Car c2 = (Car) context.getBean("car2");
		c2.printInfo();
		System.out.println("\n-----------------");
		Car c3 = (Car) context.getBean("car3");
		c3.printInfo();
		System.out.println("\n-----------------");
	}
}
