
import java.*;
import java.util.HashMap;

public class Car {
	private String model;
	private int year;
	private String maker;
	
	private static HashMap<String, String> car;
	
	public Car() {}
	
	public Car(String model, int year, String maker) {
		this.model = model;
		this.year = year;
		this.maker = maker;
	}
	
	public void printInfo()
	{
		System.out.printf("\nCar's information\n model: "+ model 
				+"\n year: "+year+"\n maker: "+maker);
	}
	

	public static void setCar() {
		car = new HashMap<String, String>();
		car.put("Sonata", "Hyundai");
		car.put("Tucson", "Hyundai");
		car.put("Soul", "Kia");
	}

	public static String getCar(String model) {
		return car.get(model);
	}

	public String getModel() {
		return model;
	}

	public int getYear() {
		return year;
	}

	public String getMaker() {
		return maker;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}
	
	
	
}
